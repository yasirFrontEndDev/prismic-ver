import { SliceComponentProps } from "@prismicio/react";

// Define the components object that will be used by the SliceZone
export const components = {};
